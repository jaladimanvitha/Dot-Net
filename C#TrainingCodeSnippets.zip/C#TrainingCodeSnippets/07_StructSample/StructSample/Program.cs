﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructSample
{
    class Program
    {
        struct Simple
        {
            public int Position;
            public bool Exists;
            public double LastValue;
        }
        static void Main(string[] args)
        {
            //This is not mandatory in the case of struct
            //It can be used without the new operator
            Simple s; 
            s.Position = 1;
            s.Exists = true;
            s.LastValue = 5.9;


            Simple s2;
            
            // This is a value type and hence the contents of s are assigned to s2
            s2 = s;


            s2.Position = 2;

            Console.WriteLine("Position of s2 " +s2.Position);
            Console.WriteLine("Position of s " + s.Position);
            Console.ReadKey();
        }
    }
}
