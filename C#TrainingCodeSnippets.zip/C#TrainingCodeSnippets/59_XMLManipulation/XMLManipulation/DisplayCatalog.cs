using System;
using System.Xml;
using System.IO;

public class Catalog
{

	private XmlDocument xmldoc;
    private string path = @"E:\ValueMatters.org\Training\Omeon\C#TrainingCodeSnippets\59_XMLManipulation\XMLManipulation\Displaycat.xml";

		public static void Main()
		{
			Catalog c= new Catalog();
		}

		public Catalog()

		//Constructor

		{
			FileStream fs = new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.ReadWrite);
			xmldoc = new XmlDocument();
			xmldoc.Load(fs);
			DisplayCatalog();
		}

		// Method for Displaying the catalog

		private void DisplayCatalog()
		{

			
			XmlNodeList xmlnode = xmldoc.GetElementsByTagName("Book");
			Console.WriteLine("Here is the list of catalogs\n\n");

			for(int i=0;i<xmlnode.Count;i++)
			{
                
			XmlAttributeCollection xmlattrc = xmlnode[i].Attributes;

			//XML Attribute Name and Value returned
			//Example: <Book id = "001">

			Console.Write(xmlattrc[0].Name);
			Console.WriteLine(":\t\t"+xmlattrc[0].Value);

			//First Child of the XML file - Catalog.xml - returned
			//Example: <Author>Mark</Author>

			Console.Write(xmlnode[i].FirstChild.Name);
			Console.WriteLine(":\t\t"+xmlnode[i].FirstChild.InnerText);

			//Last Child of the XML file - Catalog.xml - returned
			//Example: <Publisher>Sams</Publisher>

			Console.Write(xmlnode[i].LastChild.Name);
			Console.WriteLine(":\t"+xmlnode[i].LastChild.InnerText);
			Console.WriteLine();
			}
	
			Console.WriteLine("Catalog Finished");
            Console.ReadLine();
		}


		


//end of class

}