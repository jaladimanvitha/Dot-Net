using System;
using System.Xml;
using System.IO;

public class Catalog
{

    private XmlDocument xmldoc;
    string path = "Addcat.xml";

    public static void Main(string[] args)
    {
        Catalog c = new Catalog();
    }

    public Catalog()

    //Constructor
    {
        FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        xmldoc = new XmlDocument();
        xmldoc.Load(fs);
        AddCatalog();
        ReadCatalog();

    }

    // Method for Displaying the catalog


    // Adding a new entry to the catalog

    private void AddCatalog()
    {
        Console.WriteLine("New Entry is added to the catalog");
        Console.WriteLine("Please open the XML file to verify");
        Console.WriteLine("==================================");

        // New XML Element Created
        XmlElement newcatalogentry = xmldoc.CreateElement("Book");

        // New Attribute Created
        XmlAttribute newcatalogattr = xmldoc.CreateAttribute("ID");

        // Value given for the new attribute
        newcatalogattr.Value = "005";

        // Attach the attribute to the xml element
        newcatalogentry.SetAttributeNode(newcatalogattr);

        // First Element - Book - Created
        XmlElement firstelement = xmldoc.CreateElement("Author");

        // Value given for the first element
        firstelement.InnerText = "Peter";

        // Append the newly created element as a child element
        newcatalogentry.AppendChild(firstelement);


        // Second Element - Publisher - Created
        XmlElement secondelement = xmldoc.CreateElement("Publisher");

        // Value given for the second element
        secondelement.InnerText = "Que Publishing";

        // Append the newly created element as a child element
        newcatalogentry.AppendChild(secondelement);

        // New XML element inserted into the document
        xmldoc.DocumentElement.InsertBefore(newcatalogentry, xmldoc.DocumentElement.LastChild);

        // An instance of FileStream class created
        // First parameter is the path to our XML file - Catalog.xml

        FileStream fsxml = new FileStream(path, FileMode.Truncate, FileAccess.Write, FileShare.ReadWrite);

        // XML Document Saved
        xmldoc.Save(fsxml);
    }

    private void ReadCatalog()
    {
        //Get a list of all XmlNodes with the TAG Contact
        XmlNodeList bookList = xmldoc.GetElementsByTagName("Book");
        Console.WriteLine("Displaying the Books... \r\n");
        //Iterate through the Nodes
        for (int i = 0; i < bookList.Count; i++)
        {
            //Get the AttribuitesCollection for the Contact element
            XmlAttributeCollection attrColl = bookList[i].Attributes;
            //Display the Attribute Name and Value
            Console.Write("Attribute " + attrColl[0].Name);
            Console.WriteLine(":\t" + attrColl[0].Value);
            //Display the FirstChild element's Name and Text
            Console.Write("First Child " + bookList[i].FirstChild.Name);
            Console.WriteLine(":\t" + bookList[i].FirstChild.InnerText);
            //Display the LastChild element's Name and Text
            Console.Write("Last Child " + bookList[i].LastChild.Name);
            Console.WriteLine(":\t" + bookList[i].LastChild.InnerText);
            Console.WriteLine();
        }
        Console.WriteLine("Book List Over... \r\n\r\n");
        Console.ReadLine();
    }

    //end of class

}