﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace EnumerableDemo
{
    class Program
    {
        static int SimpleReturn()
        {
            return 1;
            return 2;
            return 3;
        }

        static IEnumerable<int> YieldReturn()
        {
            yield return 1;
            yield return 2;
            yield return 3;
        }

        static void Main(string[] args)
        {
            Console.WriteLine(" Simple Return");

            // Lets see how simeple return works
            Console.WriteLine(SimpleReturn());
            Console.WriteLine(SimpleReturn());
            Console.WriteLine(SimpleReturn());
            Console.WriteLine(SimpleReturn());


            Console.WriteLine("Yield Return");

            // Lets see how yield return works
            foreach (int i in YieldReturn())
            {
                Console.WriteLine(i);
            }

            Console.WriteLine();
            Console.ReadLine();
        }
    }
}
