﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SealedClass
{
    sealed class SealedClass
    {
        public int x;
        public int y;

         public string title;

         public   string Title
        {

            get
            {  return title;}
    
            set
            {
                title = value;
            }

        }
    }

    /*class FromSealed:SealedClass
    {



    }*/
   

    class SealedTest2
    {
        static void Main()
        {
            SealedClass sc = new SealedClass();
            sc.x = 110;
            sc.y = 150;
            Console.WriteLine("x = {0}, y = {1}", sc.x, sc.y);
            Console.ReadKey();
        }
    }

}
