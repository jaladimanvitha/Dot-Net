﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using AliasList = MultipleGenericTypes.LinkedList<int, string>;

namespace MultipleGenericTypes 
{

    class Node<K, T> 
    {
        public K Key;
        public T Item;
        public Node<K, T> NextNode;
        public Node()
        {
            Key = default(K);
            Item = default(T);
            NextNode = null;
        }
        public Node(K key, T item, Node<K, T> nextNode)
        {
            Key = key;
            Item = item;
              NextNode = nextNode;
        }
    }

    public class LinkedList<K, T> where K :IComparable
    {
        Node<K, T> m_Head;
        public LinkedList()
        {
            m_Head = new Node<K, T>();
        }
        public void AddHead(K key, T item)
        {
            Node<K, T> newNode = new Node<K, T>(key, item, m_Head.NextNode);
            m_Head.NextNode = newNode;
        }

        public T Find(K key)
        {
            Node<K, T> current = m_Head;
            while (current.NextNode != null)
            {
                if (current.Key.CompareTo(key) == 0)

                    break;
                else

                    current = current.NextNode;
            }
            return current.Item;
        }

       

    }

    class Program
    {
        static void Main(string[] args)
        {
            LinkedList<int, string> list = new LinkedList<int, string>();
            list.AddHead(123, "AAA");
            list.AddHead(456, "BBB");
            AliasList aliasList = new AliasList();
            aliasList.AddHead(678, "CCC");
            string item = list.Find(456);

            Debug.Assert(item == "BBB");
            


        }
    }
}
