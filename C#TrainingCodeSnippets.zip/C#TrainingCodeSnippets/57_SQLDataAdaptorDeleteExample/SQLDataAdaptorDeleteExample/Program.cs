﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace SQLAdaptorExample
{
    class Program
    {
        static void Main(string[] args)
        {
            string connetionString = null;
            SqlConnection sqlCnn;
            SqlCommand sqlCmd;
            SqlCommand deleteSqlCmd;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int i = 0;
            string sql = null;
            string deleteSql = null;

            connetionString = "Data Source=SINDHU\\SQLEXpress;Initial Catalog=TestDB;Integrated Security=true";

            sql = "Select * from products";

            deleteSql = "delete from Products  Where ProductId = @ProductId";

            sqlCnn = new SqlConnection(connetionString);
            try
            {
                sqlCnn.Open();


                sqlCmd = new SqlCommand(sql, sqlCnn);
                adapter.SelectCommand = sqlCmd;
                adapter.Fill(ds, "Products");
                for (i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {
                    Console.WriteLine(ds.Tables[0].Rows[i].ItemArray[0] + " -- " + ds.Tables[0].Rows[i].ItemArray[1]);
                }

                deleteSqlCmd = new SqlCommand(deleteSql, sqlCnn);

                // Create and update parameters for the update statement
               
                deleteSqlCmd.Parameters.Add("@ProductId", SqlDbType.Int, 10, "ProductId");
                              
                deleteSqlCmd.Parameters["@ProductId"].SourceVersion = DataRowVersion.Original;

                ds.Tables["Products"].Rows[3].Delete();

                adapter.DeleteCommand = deleteSqlCmd;

                

                adapter.Update(ds, "Products");


                adapter.Dispose();
                sqlCmd.Dispose();
                sqlCnn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Can not open connection ! ");
            }

            Console.ReadLine();
        }

    }
}