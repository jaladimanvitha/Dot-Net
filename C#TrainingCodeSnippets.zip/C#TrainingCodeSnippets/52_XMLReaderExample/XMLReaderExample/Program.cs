﻿using System;
using System.Xml;

namespace XMLReaderExample
{
    class Program
    {
        static void Main(string[] args)
        {
            const string xmlPath = @"E:\ValueMatters.org\Training\Omeon\C#TrainingCodeSnippets\52_XMLReaderExample\XMLReaderExample\Displaycat.xml";

            XmlReader xmlReaderCat = XmlReader.Create(xmlPath);
            Console.WriteLine("XML Demo begins");
            while(xmlReaderCat.Read())
            {
                if(xmlReaderCat.NodeType == XmlNodeType.Element)
                {
                    Console.WriteLine("Node Name:" + xmlReaderCat.Name);
                    Console.WriteLine("Attribute Count:" + xmlReaderCat.AttributeCount.ToString());


                }
            }
            Console.Read();
            xmlReaderCat.Close();
        }
    }
}
