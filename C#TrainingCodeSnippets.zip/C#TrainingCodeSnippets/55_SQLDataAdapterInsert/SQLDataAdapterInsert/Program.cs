﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace SQLDataAdapterInsert
{
    class Program
    {
        

        static void Main(string[] args)
        {
            string connectionString = null;
            SqlConnection connection;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql = null;
            connectionString = "Data Source= SINDHU\\SQLEXPRESS;Initial Catalog=TestDB;Integrated Security=True";
            connection = new SqlConnection(connectionString);
            sql = "insert into products (Productid,UnitPrice,ProductName) values(6,3000,'Product6')";
            try
            {
                connection.Open();
                adapter.InsertCommand = new SqlCommand(sql, connection);
                adapter.InsertCommand.ExecuteNonQuery();
                Console.WriteLine("Row inserted !! ");

            }
            catch (Exception ex)
            {
                throw;
            }
        }

    }
}
