﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace BoxingUnboxingSample
{
    class Program
    {
        static void Main(string[] args)
        {
            //Consider a value type
            int i = 38;
            //i is boxed
            object o = i;
            Console.WriteLine("The value stored in the object is " + o.ToString());

            ArrayList list =  new ArrayList();  // list is a reference type 
            int n = 38;
            string s = "hello";
            // n is a value type
            list.Add(n);
            list.Add(s);
            // n is unboxed
            n = (int)list[0];                                                         // list[0] is unboxed
           

            Console.WriteLine("The value retrieved from the Arraylist is " + n);
            Console.ReadLine();
        }
    }
}
