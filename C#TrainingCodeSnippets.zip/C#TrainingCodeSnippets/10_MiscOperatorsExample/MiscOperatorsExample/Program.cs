﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiscOperatorsExample
{
    class Program
    {
        class Apples { }
        class Oranges { }

        static void Main(string[] args)
        {
            //sizeof operator
            Console.WriteLine(" The sizeof int is " + sizeof(int));
            
            //typeof operator
            Console.WriteLine("The type of integer is " +  typeof(int).ToString());

            int j = 890;
            //using unsafe is not recommended
            unsafe
            {
                int* p = &j;
                
                Console.WriteLine("The address of variable i is " + (int)p);
            }

            //As operator
            object[] objArray = new object[6];
            objArray[0] = new Apples();
            objArray[1] = new Oranges();
            objArray[2] = "hello";
            objArray[3] = 123;
            objArray[4] = 123.4;
            objArray[5] = null;

            for (int i = 0; i < objArray.Length; ++i)
            {
                string s;
                try
                {

                     s = objArray[i] as string;
                // s = (string)objArray[i];
                Console.Write("{0}:", i);
                if (s != null)
                {
                    Console.WriteLine("'" + s + "'");
                }
                else
                {
                    Console.WriteLine("not a string");
                }

                }

                catch (InvalidCastException e)
                {
                    Console.WriteLine("This is an InvalidCast ");
                    continue;
                }
            }
            

            //is operator checks if the object type is compatible

            object testApples = new Apples();

            

            if(testApples is Apples)
            {
                Console.WriteLine(" The object is of type Apples");
            }
            

            // The conditional operator
            int h = -89;

            string isNumberPositive = h> 0 ? "is positive" : "is Negative";

            Console.WriteLine(isNumberPositive);

            Console.ReadLine();
        }
    }
}
