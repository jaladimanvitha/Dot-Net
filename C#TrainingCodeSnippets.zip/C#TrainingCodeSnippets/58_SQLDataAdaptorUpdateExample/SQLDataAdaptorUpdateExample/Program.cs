﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace SQLAdaptorExample
{
    class Program
    {
        static void Main(string[] args)
        {
            string connetionString = null;
            SqlConnection sqlCnn;
            SqlCommand sqlCmd;
            SqlCommand updateSqlCmd;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int i = 0;
            string sql = null;
            string updateSql = null;

            connetionString = "Data Source=SINDHU\\SQLEXpress;Initial Catalog=TestDB;Integrated Security=true";

            sql = "Select * from products";

            updateSql = "Update Products set ProductName = @ProductName Where ProductId = @ProductId";

            sqlCnn = new SqlConnection(connetionString);
            try
            {
                sqlCnn.Open();


                sqlCmd = new SqlCommand(sql, sqlCnn);
                adapter.SelectCommand = sqlCmd;
                adapter.Fill(ds,"Products");
                for (i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {
                    Console.WriteLine(ds.Tables[0].Rows[i].ItemArray[0] + " -- " + ds.Tables[0].Rows[i].ItemArray[1]);
                }

                updateSqlCmd = new SqlCommand(updateSql,sqlCnn);

                // Create and update parameters for the update statement
                updateSqlCmd.Parameters.Add("@ProductName", SqlDbType.VarChar, 50, "ProductName");
                updateSqlCmd.Parameters.Add("@ProductId", SqlDbType.Int, 10, "ProductId");

                updateSqlCmd.Parameters["@ProductName"].SourceVersion = DataRowVersion.Current;
                updateSqlCmd.Parameters["@ProductId"].SourceVersion = DataRowVersion.Original;

                adapter.UpdateCommand = updateSqlCmd;

                ds.Tables[0].Rows[3]["ProductName"] = "Lava";

                adapter.Update(ds, "Products");


                adapter.Dispose();
                sqlCmd.Dispose();
                sqlCnn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Can not open connection ! ");
            }

            Console.ReadLine();
        }

    }
}