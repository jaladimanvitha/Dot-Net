﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace enumTypes
{
    class Program
    {
        enum MaritalStatus
        {
            Married = 1,
            UnMarried = 2
        };
        static void Main(string[] args)
        {
            Console.WriteLine(MaritalStatus.UnMarried);
        }
        Console.ReadLine();
    }
}
