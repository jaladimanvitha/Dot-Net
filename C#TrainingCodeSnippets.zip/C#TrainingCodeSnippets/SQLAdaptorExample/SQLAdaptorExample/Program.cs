﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace SQLAdaptorExample
{
    class Program
    {
        static void Main(string[] args)
        {
            //1
            //Open a connection
           SqlConnection c = new SqlConnection(
       "Data Source=SINDHU\\SQLEXPRESS;Initial Catalog=TestDb;"
                + "Integrated Security=true") ;
            
                c.Open();
                // 2
                // Create new DataAdapter
                using (SqlDataAdapter a = new SqlDataAdapter(
                    "SELECT * FROM Products", c))
                {
                    // 3
                    // Use DataAdapter to fill DataTable
                    DataTable t = new DataTable();
                    a.Fill(t);

                    int colCount = t.Columns.Count;

                    // 4
                    // Render data onto the console
                    foreach(DataRow dr in t.Rows)
                    {
                        for (int i = 0; i < colCount; i++ )
                        {
                            Console.WriteLine(dr[i]);
                        }
                            
                    }
                    Console.ReadLine();
                }
            }

        }
    
}
