﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// This is a namespace
namespace DotNetBegins
{
    class Program
    {
              
        // Main Method
        /*
         * Dot net class begins
         */
        static void Main(string[] args)
        {
           
            Console.WriteLine("DotNet Begins");
            Console.ReadKey();
           
        }
    }
}
