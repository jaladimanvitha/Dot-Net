﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _43e_GenericsAbstractClass
{
    public abstract class BaseCalculator<T>
    {
        public abstract T Add(T arg1, T arg2);
        public abstract T Subtract(T arg1, T arg2);
        public abstract T Divide(T arg1, T arg2);
        public abstract T Multiply(T arg1, T arg2);
              
    }
    public class MyCalculator : BaseCalculator<int>
    {
        public override int Add(int arg1, int arg2)
        {
            return arg1 + arg2;
        }

        public override int Subtract(int arg1, int arg2)
        {
            return arg1 - arg2;
        }

        public override int Multiply(int arg1,int arg2)
        {
            return arg1 * arg2;
        }

        public override int Divide(int arg1, int arg2)
        {
            return arg1 /arg2;
        }
    } 


    class Program
    {
        static void Main(string[] args)
        {
            MyCalculator specCalculator = new MyCalculator();
            int result = specCalculator.Add(1, 2);
            Console.WriteLine(result);
            Console.Read();
        }
    }
}
