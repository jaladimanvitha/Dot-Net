﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringEssentials
{
    class Program
    {
        static void Main(string[] args)
        {

            //Strings are immutable
            string s1 = "A string is more ";
            string s2 = "than the sum of its chars.";

            // Concatenate s1 and s2. This actually creates a new 
            // string object and stores it in s1, releasing the 
            // reference to the original object.
            s1 += s2;

           

            //How to concatenate strings - Learn the right way

            // Use StringBuilder for concatenation in tight loops.
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            for (int i = 0; i < 100; i++)
            {
                sb.Append(i.ToString());
            }
            System.Console.WriteLine(sb.ToString());

            // Keep the console window open in debug mode.
            System.Console.WriteLine("Press any key to exit.");
            System.Console.ReadKey();

           

        }

    }
}
