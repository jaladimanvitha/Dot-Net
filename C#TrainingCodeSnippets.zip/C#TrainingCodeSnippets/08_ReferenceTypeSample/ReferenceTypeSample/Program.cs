﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReferenceTypeSample
{
    class Program
    {
        class SampleClass
        {
            public int value;
        }

        static void Main(string[] args)
        {
            //create an instance of the class
            /* multi
             * line */
            SampleClass testRef1 = new SampleClass();
            SampleClass testRef2 = new SampleClass();
            testRef2 = testRef1;
            testRef1.value = 20;

            Console.WriteLine(" The value in testRef1 is " + testRef1.value);
            Console.WriteLine(" The value in testRef2 is " + testRef2.value);
            Console.ReadLine();
        }
    }
}
