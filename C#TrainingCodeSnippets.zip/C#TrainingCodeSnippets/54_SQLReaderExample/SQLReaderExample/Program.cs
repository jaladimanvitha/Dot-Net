﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace SQLReaderExample
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString;
            connectionString = @"Data Source=SINDHU\SQLEXPRESS;Initial Catalog=NorthWind;Integrated Security=True";
            SqlConnection connection;
            SqlDataReader reader;
            connection = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand();
            



            try
            {
                cmd.CommandText = "dbo.Customers By City";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = connection;

                cmd.Parameters.Add("@param1", SqlDbType.NVarChar).Value = "SanJose";
                


                connection.Open();

                reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    Console.WriteLine("Customer id {0}", reader.GetString(0));
                    Console.WriteLine("Contact Name  {0}", reader.GetString(1));
                    Console.WriteLine("Company Name {0}", reader.GetString(2));
                    Console.WriteLine("City {0}", reader.GetString(3));
                }

                Console.ReadKey();
                connection.Close();

            }
            catch (Exception ex)
            {
                throw;
            }

        }
    }
}
