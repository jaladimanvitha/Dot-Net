﻿using System;
using TraineeDetails;
using TrainerDetails;


    namespace TrainerDetails
    {
        class Trainer
        {
            public void Role()
            {
                Console.WriteLine("Trainer's role is to conduct workshop on Programming in C#");
            }

        }
    }
    
    namespace TraineeDetails
    {
        
        class Trainee
        {
            public void Goal()
            {
                Console.WriteLine("Trainee's goal is to Program in C# like breeze");
            }

        }
    }


    namespace IntroducingNamespace
   {
    class CallingProgram
    {
        static void Main(string[] args)
        {
            Trainer trainerCSharp = new TrainerDetails.Trainer();
            Trainee traineeCSharp = new TraineeDetails.Trainee();

            trainerCSharp.Role();
            traineeCSharp.Goal();
            Console.ReadKey();
        }
    }
    
}
