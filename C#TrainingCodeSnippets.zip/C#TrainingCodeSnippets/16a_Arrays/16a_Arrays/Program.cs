﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _16a_Arrays
{
    class TestArraysClass
    {
        static void Main()
        {
            // Declare and initialize an array: 
            int[,] theArray = new int[5, 10];
            Console.WriteLine("The array has {0} dimensions.", theArray.Rank);
            
            int[] theSingleDimArray = new int[15];
            Console.WriteLine("The array has {0} dimensions and the array has {1} dimension.", theSingleDimArray.Rank, theArray.Rank);

            Console.ReadLine();
        }

        
    }

}
