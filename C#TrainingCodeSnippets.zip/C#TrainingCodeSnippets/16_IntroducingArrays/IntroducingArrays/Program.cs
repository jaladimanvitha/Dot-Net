﻿using System;
class DeclareArraysSample
{
    public static void Main()
    {
        // Single-dimensional array
        int[] numbers = new int[5];

        numbers[0] = 10;
        numbers[1] = 20;
        numbers[2] = 30;
        numbers[3] = 40;
        numbers[4] = 50;

        //using foreach in arrays
        
        foreach (int i in numbers)
        {
            System.Console.WriteLine(i);
        }

        Console.WriteLine("The array has {0} dimensions.", numbers.Rank);


        // Multidimensional array
        string[,] names = new string[2, 2];
        names[0, 0] = "Hello";
        names[0, 1] = "World";
        names[1, 0] = "Good";
        names[1, 1] = "Day";
        
        //iterate thru the array
        foreach(string s in names)
        {
            System.Console.WriteLine(s);
        }

        Console.WriteLine("The array has {0} dimensions.", names.Rank);

        // Array-of-arrays (jagged array)
        byte[][] scores = new byte[5][];

        // Create the jagged array
        for (int i = 0; i < scores.Length; i++)
        {
            scores[i] = new byte[i+1];
        }

        // Print length of each row
        for (int i = 0; i < scores.Length; i++)
        {
            Console.WriteLine("Length of row {0} is {1}", i, scores[i].Length);
            Console.WriteLine("The array has {0} dimensions.", scores[i].Rank);
        }

        

        Console.ReadLine();
    }
}
