﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DataSetExample
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString;
            connectionString = @"Data Source=SINDHU\SQLEXPRESS;Initial Catalog=NorthWind;Integrated Security=True";
            SqlConnection connection;
            SqlDataAdapter adpater = new SqlDataAdapter();
            connection = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand();
            DataSet ds = new DataSet();




            try
            {
                cmd.CommandText = "dbo.Customers By City";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = connection;

                cmd.Parameters.Add("@param1", SqlDbType.NVarChar).Value = "SanJose";

                adpater.SelectCommand = cmd;

                connection.Open();
                adpater.Fill(ds);

                connection.Close();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    Console.WriteLine(ds.Tables[0].Rows[i]["CustomerID"].ToString());

                Console.ReadKey();
              

            }
            catch (Exception ex)
            {
                throw;
            }

        }
    }
}
