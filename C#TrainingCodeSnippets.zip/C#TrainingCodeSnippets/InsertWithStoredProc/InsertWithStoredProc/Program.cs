﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace InsertWithStoredProc
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString;
            connectionString = @"Data Source=SINDHU\SQLEXPRESS;Initial Catalog=NorthWind;Integrated Security=True";
            SqlConnection connection;
            
            connection = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand();
            int rowsAffected;



            try
            {
                cmd.CommandText = "dbo.sp_Insert_Customers";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = connection;

                cmd.Parameters.Add("@CustomerID", SqlDbType.NChar).Value = "YYkk";
                cmd.Parameters.Add("@CompanyName", SqlDbType.NVarChar).Value = "AtoZ";
                cmd.Parameters.Add("@ContactName", SqlDbType.NVarChar).Value = "Paul Simon";
                cmd.Parameters.Add("@ContactTitle", SqlDbType.NVarChar).Value = "Manager";
                cmd.Parameters.Add("@Address", SqlDbType.NVarChar).Value = "15 ABC Street";
                cmd.Parameters.Add("@City", SqlDbType.NVarChar).Value = "SanJose";
                cmd.Parameters.Add("@PostalCode", SqlDbType.NVarChar).Value = "80336";
                cmd.Parameters.Add("@Country", SqlDbType.NVarChar).Value = "USA";



                connection.Open();

                rowsAffected = cmd.ExecuteNonQuery();
                Console.WriteLine("Row inserted !! ");
                connection.Close();

            }
            catch (Exception ex)
            {
                throw;
            }


        }
    }
}
