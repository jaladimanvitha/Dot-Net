﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace XMLWriterSample
{
    class Program
    {
        static void Main(string[] args)
        {
            const String xmlPath = @"E:\ValueMatters.org\Training\Omeon\C#TrainingCodeSnippets\53_XMLWriterSample\NewDisplaycat.xml";
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;

            XmlWriter writer = XmlWriter.Create(xmlPath, settings);

            //Opens the Xml Document
            writer.WriteStartDocument();

            //Write Comments
            writer.WriteComment("Display Catalog");


            //Write the start element
            writer.WriteStartElement("Books");
            writer.WriteStartElement("Book");
            writer.WriteStartElement("Book1");
          
            writer.WriteAttributeString("ID", "003");
            writer.WriteEndElement();
            writer.WriteEndElement();

           

            writer.WriteEndDocument();

            writer.Close();


        }
    }
}
