﻿using System;

namespace XMLDocument
{
    class Program
    {
        static void Main(string[] args)
        {
            XMLDocument doc = new XMLDocument();
            doc.
        }
    }
}
