﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiscEquals
{
    class Program
    {
        static void Main(string[] args)
        {
            object o = "Hello World";
            object o1 =  new String(("Hello World").ToCharArray());

            Console.WriteLine(o == o1);
            Console.WriteLine(o.Equals(o1));

            Console.Read();
        }
    }
}
