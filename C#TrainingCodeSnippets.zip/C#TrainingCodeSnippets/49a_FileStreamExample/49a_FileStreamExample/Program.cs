﻿using System;
using System.IO;
using System.Drawing;

namespace FileIOApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //The FileMode enumerator defines various methods for opening files
            //FileAccess enumerators have members: Read, ReadWrite and Write.
            FileStream F = new FileStream("test.dat", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            for (int i = 0; i <= 20; i++)
            {
                F.WriteByte((byte)i);
            }

            F.Position = 0;
            for (int i = 0; i <= 20; i++)
            {
                Console.Write(F.ReadByte() + " ");
            }
            F.Close();
            Console.ReadKey();
        }
    }
}