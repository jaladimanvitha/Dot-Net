﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsinStruct
{
    class Program
    {
        public struct Point<T>
        {

            public T X;

            public T Y;
        }

        static void Main(string[] args)
        {
            Point<int> point;

            point.X = 1;
            point.Y = 2;

            Point<double> doublePoint;
            doublePoint.X = 12.44;
            doublePoint.Y = 56.33;


            Console.WriteLine("The integer struct values are " + point.X + " and " + point.Y);
            Console.WriteLine("The double struct values are " + doublePoint.X + " and " + doublePoint.Y);

            Console.Read();
            
        }
    }
}
