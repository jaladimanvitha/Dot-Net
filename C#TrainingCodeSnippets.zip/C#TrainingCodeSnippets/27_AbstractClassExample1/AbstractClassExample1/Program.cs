﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassExample1
{
     public abstract class Media
        {
            //Title
             string title;
            //Year
             string year;
            //Company
             string company;

            public abstract string Title
            {
                get;
                set;
            }

            public abstract string Year
            {
                get;
                set;
            }

            public abstract string Company
            {
                get;
                set;
            }
            
            public abstract string Publish();
            
        }

        public class CD : Media
        {

            //Title
            String cdTitle;
            //Year
            String cdYear;
            //Company
            String cdCompany;

            public override string Title
            {
                set
                {
                    cdTitle = value;
                }

                get
                {
                    return cdTitle;
                }
            }


            public override string Company
            {
                set
                {
                    cdCompany = value;
                }

                get
                {
                    return cdCompany;
                }
            }

            public override string Year
            {
                set
                {
                    cdYear = value;
                }

                get
                {
                    return cdYear;
                }
            }
            public override string Publish()
            {
                return String.Format("CD Launch of {0}, on {1} by {2}",  Title ,Year,Company);
            }

            
        }

        public class PrintMagazine : Media
        {

            //Title
            String printTitle;
            //Year
            String printYear;
            //Company
            String printCompany;

            public override string Title
            {
                set
                {
                    printTitle = value;
                }

                get
                {
                    return printTitle;
                }
            }


            public override string Company
            {
                set
                {
                    printCompany = value;
                }

                get
                {
                    return printCompany;
                }
            }

            public override string Year
            {
                set
                {
                    printYear = value;
                }

                get
                {
                    return printYear;
                }
            }


            public override string Publish()
            {
                return String.Format("Book Launch of {0}, on {1} by {2}", Title, Year, Company);
            }

        }

        public class Store
        {
            static void Main(string[] args)
            {
              

                //Title
                String bookTitle = "C# Essentails";
                //Year
                String bookYear = "2014";
                //Company
                String bookCompany = "The C# Company";


                //Title
                String cdTitle = "C# Programming";
                //Year
                String cdYear = "2014";
                //Company
                String cdCompany = "The C#  CD Company";
             


                PrintMagazine print = new PrintMagazine();
                print.Title = bookTitle;
                print.Company = bookCompany;
                print.Year = bookYear;

                string publishBook = print.Publish();
                
                CD cd = new CD();
                cd.Title= cdTitle;
                cd.Company = cdCompany;
                cd.Year = cdYear;

                cd.Publish();

                string publishCD = cd.Publish();

                Console.WriteLine(publishBook);
                Console.WriteLine(publishCD);
                Console.ReadLine();

            }
        }
        
    }

