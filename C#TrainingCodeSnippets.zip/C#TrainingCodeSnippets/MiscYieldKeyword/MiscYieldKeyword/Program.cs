﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiscYieldKeyword
{
    class Program
    {
        static void Main(string[] args)
        {
            foreach(int i in YieldReturn())
            {
                Console.WriteLine(i);
            }
            Console.Read();
        }

        static IEnumerable<int> YieldReturn()
        {
            yield return 1;
            
            yield return 3;
        }
    }
}
