﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;

namespace  AsyncAwait
{
    class Program
    {
        static void Main(string[] args)
        {
            Task<string> getWebPageTask = GetWebPageAsync("http://www.microsoft.com");

            string text = getWebPageTask.Result;

            Console.WriteLine(text.Length);
            Console.ReadLine();

            
        }

        static async Task<string> GetWebPageAsync(string url)
        {
            Task<string> getStringTask = (new System.Net.Http.HttpClient()).GetStringAsync(url);

            Console.WriteLine("Before Await GetWebPageAsync");

            string webText = await getStringTask;
            Console.WriteLine("After Await GetWebPageAsync");

            return webText;
        }
    }
}
