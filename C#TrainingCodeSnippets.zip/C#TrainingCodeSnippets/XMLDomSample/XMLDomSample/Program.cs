﻿using System;
using System.Xml;

namespace XMLDomSample
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlDocument xmldoc = new XmlDocument();
            xmldoc.Load(@"E:\ValueMatters.org\Training\Omeon\C#TrainingCodeSnippets\52_XMLReaderExample\XMLReaderExample\displaycat.xml");

            XmlNode booknode = xmldoc.CreateElement("Book");

            XmlAttribute xattribute = xmldoc.CreateAttribute("ID");
            xattribute.Value ="3";

            booknode.Attributes.Append(xattribute);


            xmldoc.Save("doc.xml");
            

        }
    }
}
