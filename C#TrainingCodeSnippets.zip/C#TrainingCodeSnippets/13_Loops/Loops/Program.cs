﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Loops
{
    class Program
    {
        static void Main(string[] args)
        {
            /* local variable definition */
            int a = 1;

            /* while loop execution */
            Console.WriteLine("The while loop");
            while (a < 5)
            {
               Console.WriteLine("value of a: {0}", a);
                a++;
            }


            /* for loop execution */
            Console.WriteLine("The for loop");
            for (int i = 10; i < 16; i = i + 1)
            {             
                
                if (i == 14)
                   break;

                if (i == 13)
                    continue;
                Console.WriteLine("value of i: {0}", i);
            }


            /* local variable definition */
            int j = 10;

            /* do loop execution */
            Console.WriteLine("The do while loop");
            do
            {               
                Console.WriteLine("value of j: {0}", j);
               j = j + 1;
            } while (j < 16);


           

            /* for each loop */

            int[] numbers = { 1, 2, 3 };

            foreach( int i in numbers)
            {
                Console.WriteLine(" The number is " + i);
            }
            Console.ReadLine();
        }
    }
}
