﻿using System;


namespace IntroducingAccessSpecifiers
{
    class Bicycle
    {
        //protected member
        protected void Pedal() { }

        //private field
        private int wheels = 2;

        //protected internal property
        //A property is a member that provides a flexible mechanism to read, write, or compute the value of a private field
        protected internal int Wheels
        {
            get { return wheels; }
        }

        
    }

      

    class Program
    {
        static void Main(string[] arguments)
        {
            Bicycle myBicycle = new Bicycle();
            
            
            Console.WriteLine("My bicycle  has " + myBicycle.Wheels.ToString() + " wheels");

            Console.ReadLine();
        }
    }
}
